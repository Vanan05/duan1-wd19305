<?php
class homeController
{
    public function index()
    {
        // Lấy danh sách Cosmetics
        $product = new Product;
        $cosmetics = $product->listCosmetics();
        $list_products = $product->listBasicCosmetics();

        // Lấy danh mục
        $categories = (new Category)->all();

        // Lấy giỏ hàng từ session
        $carts = $_SESSION['cart'] ?? []; // Nếu chưa có giỏ hàng, mặc định là mảng rỗng

        // Tính tổng số lượng sản phẩm trong giỏ hàng
        $totalQuantity = (new CartController)->totalQuantityCart($carts);

        //Lưu URI vào session
        $_SESSION['URI'] = $_SERVER['REQUEST_URI'];

        // Trả về view với các dữ liệu cần thiết
        return view("clients.home",
            compact('cosmetics', 'list_products', 'categories', 'totalQuantity'));
    }
}
