<?php
   
class CartController
{
    public function addCart()
    {
        // Kiểm tra xem URI đã có trong session chưa
        if (!isset($_SESSION['URI'])) {
            // Lưu đường dẫn hiện tại vào session nếu chưa có
            $_SESSION['URI'] = $_SERVER['REQUEST_URI']; 
        }

        $carts = $_SESSION['cart'] ?? []; // tạo giỏ hàng

        // lấy id để thêm vào giỏ hàng
        $id = $_GET['id'];
        // lấy sản phẩm theo id
        $product = (new Product)->find($id);
        // Kiểm tra sản phẩm có trong giỏ hàng
        if (isset($carts[$id])) {
            $carts[$id]['quantity'] += 1;
        } else {
            $carts[$id] = [
                'name' => $product['name'],
                'image' => $product['image'],
                'price' => $product['price'],
                'quantity' => 1
            ];
        }
        // Lưu giỏ hàng vào session
        $_SESSION['cart'] = $carts;

        // Lưu số lượng sản phẩm trong giỏ hàng
        $_SESSION['totalQuantity'] = $this->totalQuantityCart($carts);

        // Lấy URI từ session để chuyển hướng người dùng
        $uri = $_SESSION['URI']; // Nếu không có URI, chuyển về trang chủ
        header("Location: " . $uri); // Điều hướng về URI đã lưu
    }

    // Các phương thức khác



    //tình tổng số lượng sản phẩm trong giỏ hàng
    public function totalQuantityCart($carts)
    {
        $totalQuantity = 0;
        foreach ($carts as $cart) {
            $totalQuantity += $cart['quantity'];
        }
        return $totalQuantity;
    }

    //Tính tổng tiền trong giỏ hàng
    public function totalPriceInOrder()
    {
        $carts = $_SESSION['cart'] ?? [];

        $total = 0;
        foreach ($carts as $cart) {
            $total += $cart['price'] * $cart['quantity'];
        }
        return $total;
    }

    //Hiển thị giỏ hàng
    public function viewCart()
    {
        $carts = $_SESSION['cart'] ?? [];
        $totalPriceInOrder = $this->totalPriceInOrder();
        $categories = (new Category)->all();
        $totalQuantity = (new CartController)->totalQuantityCart($carts);

        return view('clients.carts.cart', compact('carts', 'totalPriceInOrder', 'categories', 'totalQuantity'));
    }

    //Xóa sản phẩm trong giỏ hàng
    public function deleteProductInCart()
    {
        //lấy id sản phẩm
        $id = $_GET['id'];
        //Xóa sản phẩm trong giỏ hàng
        unset($_SESSION['cart'][$id]);
        //chuyển về giỏ hàng
        $_SESSION['totalQuantity'] = (new CartController)->totalPriceInOrder();
        return header("location: " . ROOT_URL . '?ctl=view-cart');
    }

    //Cập nhật giỏ hàng
    public function updateCart()
    {

        $quantities = $_POST['quantity'];
        foreach ($quantities as $id => $qty) {
            $_SESSION['cart'][$id]['quantity'] = $qty;
        }
        return header("Location: " . ROOT_URL . '?ctl=view-cart');
    }
    
    //Hiển thị thông tin thanh toán
    public function viewCheckout() {
        //kiểm tra xem người dùng đăng nhập chưa, nếu chưa thì vào login
        if (!isset($_SESSION['user'])) {
            return header("location: " . ROOT_URL . '?ctl=login');
    }

    $user = $_SESSION['user'];
    $carts = $_SESSION['carts'] ?? [];
    $totalQuantity = (new CartController)->totalQuantityCart($carts);
    return view("clients.carts.checkout", compact('user', 'carts', 'totalQuantity'));
}
}