            <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <h2>Already have an account</h2>
                    <button class="ghost" id="signIn">Sign In</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <h2>No account</h2>
                    <button class="ghost" id="signUp">Sign Up</button>
                </div>
            </div>
        </div>
<?php require_once ROOT_DIR . "views/account/footer.php" ?>
